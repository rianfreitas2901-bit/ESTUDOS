def saudacao(nome = "Visitante"):
    no = nome
    if no == nome:
        print("Boas vindas ", no)
    else:
        print("Boas vindas", nome)


saudacao()