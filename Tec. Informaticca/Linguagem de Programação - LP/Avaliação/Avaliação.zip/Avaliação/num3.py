def soma(A, B):
    sm = A + B
    print(sm)

soma(9, 8)