#Mover o mouse em diferentes posições
import pyautogui
import time

pyautogui.moveTo(200, 0, duration= 1)
time.sleep(1)
pyautogui.moveTo(100, 50, duration= 1)
time.sleep(1)
pyautogui.moveTo(150, 100, duration= 1)
time.sleep(1)

#----------------------------------------------------------