#Posição do Mouse
import pyautogui
import time

for _ in range(5):
    print(pyautogui.position())
    time.sleep(1)

#----------------------------------------------------------