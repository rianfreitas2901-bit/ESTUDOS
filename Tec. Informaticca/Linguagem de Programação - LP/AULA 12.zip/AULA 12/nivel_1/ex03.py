#Clicar em uma posição específica (ex: Chrome)
import pyautogui
import time

time.sleep(3)
pyautogui.click(x=1246, y=1056)